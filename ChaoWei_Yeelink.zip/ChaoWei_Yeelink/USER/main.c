#include <string.h>
#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "timer7.h"

#include "lwip/netif.h"
#include "lwip_comm.h"
#include "lwipopts.h"
#include "tcp_client.h"

#include "FreeRTOS.h"
#include "task.h"

#include "yeelink_1.h"


//��������=====================================================================
static TaskHandle_t     hd_DNS_Yeelink_Task;
//-----------------------------------------------------------------------------


//����������=================================================================
void LED_Task(void *p);
void KEY_Task(void *p);
void YeeLink_DNS_Task(void *p);
void Yeelink_Req_Task(void *p);
//-----------------------------------------------------------------------------

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	uart_init(115200);
	led_init();
	key_init();
    lwip_comm_init();
    Yeelink_Variable_Init();

#if LWIP_DHCP
    lwip_comm_dhcp_create();
#endif

//    xTaskCreate(LED_Task,
//                "LED Task",
//                configMINIMAL_STACK_SIZE,
//                NULL,
//                1,
//                NULL    );

//    xTaskCreate(KEY_Task,
//                "KEY Task",
//                configMINIMAL_STACK_SIZE,
//                NULL,
//                1,
//                NULL    );

    xTaskCreate(YeeLink_DNS_Task,
                "Yeelink DNSTask",
                configMINIMAL_STACK_SIZE,
                NULL,
                4,
                hd_DNS_Yeelink_Task    );

    xTaskCreate(Yeelink_Req_Task,
                "Yeelink ReqTask",
                configMINIMAL_STACK_SIZE,
                NULL,
                3,
                NULL    );

    vTaskStartScheduler();

    while(1);
}


//����������
//=============================================================================
void LED_Task(void *p)
{

    while(1)
    {
        //LED1=!LED1;

        vTaskDelay(500);
    }
}

void KEY_Task(void *p)
{
    while(1)
    {
        if(key_scan(1)==KEY4_PRES)
        {
            tcp_client_flag|=LWIP_SEND_DATA;
        }
        vTaskDelay(50);
    }
}

void YeeLink_DNS_Task(void *p)
{
    while(Yeelink_DNS_OK==0)
    {
        Yeelink_DNS_Parse();
    }
    vTaskDelete(hd_DNS_Yeelink_Task);
}

void Yeelink_Req_Task(void *p)
{
    CurSensor = 1;

    while(1)
    {
        if(Yeelink_DNS_OK==1)
        {
            for(CurSensor=1; CurSensor<=SENSOR_NUM; CurSensor++)
            {
                Yeelink_Polling(CurSensor);
                vTaskDelay(REQUEST_INTERVAL); 
            }
        }
    }
}

//-----------------------------------------------------------------------------


