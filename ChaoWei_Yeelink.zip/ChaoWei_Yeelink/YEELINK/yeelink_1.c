#include "yeelink_1.h"


//��������================================================================================================
ip_addr_t  Yeelink_IP;
u8         Yeelink_DNS_OK;
char       Yeelink_Request_Seq[YEELINK_SEQ_SIZE];
char      *Yeelink_ID_Lib[SENSOR_NUM+1];            //ָ�����飬��0��Ԫ��ָ���豸ID�����涼�Ǵ�����ID
u8         CurSensor = 0xFF;                        //��ǰ��ѯ�Ĵ������ţ��ⲻ��һ��Ҫ����Yeelink����
//--------------------------------------------------------------------------------------------------------


void Yeelink_DNS_Parse()
{
    u8_t       ip[4];
    ip_addr_t  addr;
    
    if(netconn_gethostbyname(HOST_NAME, &addr)==ERR_OK)
    {
        Yeelink_DNS_OK = 1;
        Yeelink_IP = addr;
        
        ip[0] = Yeelink_IP.addr>>24; 
        ip[1] = Yeelink_IP.addr>>16;
        ip[2] = Yeelink_IP.addr>>8; 
        ip[3] = Yeelink_IP.addr; 

        printf("%d.%d.%d.%d\r\n",ip[3], ip[2], ip[1], ip[0]);
    }
}

void Yeelink_Variable_Init()
{
    Yeelink_ID_Lib[0] = DEVICE_ID;
    Yeelink_ID_Lib[1] = SENSOR_LED1_ID;
    Yeelink_ID_Lib[2] = SENSOR_LED2_ID;
    Yeelink_ID_Lib[3] = SENSOR_LED3_ID;
    Yeelink_ID_Lib[4] = SENSOR_LED4_ID;
}

/*
 * ��佫Ҫ��Yeelink���͵���������
 * ����һ���豸�ź�һ����������
 */
static void Yeelink_Seq_Fill(const char *pDevice, const char *pSensor)
{
    memset(Yeelink_Request_Seq,0,YEELINK_SEQ_SIZE);
    sprintf(Yeelink_Request_Seq,
            "%s%s%s%s%s%s%s%s%s%s%s%s%s%s",                                    
            YEELINK_REQ_SEQ_1 ,   //1   GET /v1.0/device/                              
            pDevice           ,   //2   �豸��
            YEELINK_REQ_SEQ_2 ,   //3   /sensor/                                       
            pSensor           ,   //4   ��������
            YEELINK_REQ_SEQ_3 ,   //5   /datapoints HTTP/1.1 
            YEELINK_REQ_SEQ_4 ,   //6   Host:api.yeelink.net 
            YEELINK_REQ_SEQ_5 ,   //7   U-ApiKey:                                      
            API_KEY           ,   //8   API��
            YEELINK_REQ_SEQ_6 ,   //9   Accept: */* 
            YEELINK_REQ_SEQ_7 ,   //10  Content-Type: application/x-www-form-urlencoded
            YEELINK_REQ_SEQ_8 ,   //11  Connection: close 
            YEELINK_REQ_SEQ_9 ,   //12  \r\n 
            YEELINK_REQ_SEQ_10,   //13  \r\n 
            YEELINK_REQ_SEQ_11    //14  ------207 
           );
    
//    printf("%s",Yeelink_Request_Seq);           //�����ã��۲�seq�Բ���
//    while(1);                                   //�����ã��۲�seq�Բ���
}

void Yeelink_Polling(u8 n)
{
    static u8  tcp_client_init_flag;
    
    Yeelink_Seq_Fill(Yeelink_ID_Lib[0], Yeelink_ID_Lib[n]);
    if(tcp_client_init_flag==0)
    {
        tcp_client_init();
        tcp_client_init_flag = 1;
    }
    
    tcp_client_sendbuf = (u8*)Yeelink_Request_Seq;                 //ע�ⷢ�ͳ�ȥ�ı������ַ���������
    tcp_client_flag |= LWIP_SEND_DATA;
}

static u8 Yeelink_Analyze(void *pBuf)
{  
    char  *pbuf_TCP_Recv = pBuf;
    char  *p_res;
           
    /* Yeelink���صĸ�ʽ��
       str_tmp(  timestamp_tmp( timestamp  ), value_tmp(  value  ) )
    */
           char   str_tmp[50]={0}; 
           char   timestamp_tmp[30]={0};
           char   value_tmp[10]={0};
           char   timestamp[20]={0};
    static char   value[5]={0};
    
    p_res = strstr( (const char *)pbuf_TCP_Recv , (const char *)"200 OK\r\n");
    if(p_res==NULL)
        return 0xFF;

    sscanf(pbuf_TCP_Recv,"%*[^{]{%[^}]",str_tmp);
    sscanf(str_tmp,"%[^,],%[^,]",timestamp_tmp,value_tmp);
    strncpy(timestamp,strstr(timestamp_tmp,":")+2,strlen(strstr(timestamp_tmp,":"))-3);
    strncpy(value,strstr(value_tmp,":")+1,strlen(strstr(value_tmp,":"))-1);

    return (value[0]-0x30);
}


void Yeelink_Do_After_Recv(void *p)
{
    u8  res;
    
    res = Yeelink_Analyze(p);
    if(res==0xFF)
        return;
    
    switch(CurSensor)
    {
        case 1:
            if(res==1)
            {
                LED1 = 0;
            }
            else if(res==0)
            {
                LED1 = 1;
            }
            break;
            
        case 2:
            if(res==1)
            {
                LED2 = 0;
            }
            else if(res==0)
            {
                LED2 = 1;
            }
            break;

        case 3:
            if(res==1)
            {
                LED3 = 0;
            }
            else if(res==0)
            {
                LED3 = 1;
            }
            break;

        case 4:
            if(res==1)
            {
                LED4 = 0;
            }
            else if(res==0)
            {
                LED4 = 1;
            }
            break;            
    }
}


