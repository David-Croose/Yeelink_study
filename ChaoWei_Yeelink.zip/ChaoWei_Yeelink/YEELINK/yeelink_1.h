#ifndef _YEELINK_H_
#define _YEELINK_H_

#include <string.h>
#include <stdio.h>
#include "stm32f4xx.h"
#include "lwip/tcp.h"
#include "dns.h"
#include "lwip/netif.h"
#include "lwip_comm.h"
#include "lwipopts.h"
#include "tcp_client.h"



//������===========================================================================================================
#define  YEELINK_SEQ_SIZE    (230)                                            //��Yeelink���͵������ַ��������С
#define  SENSOR_NUM          (4)                                              //������������
#define  REQUEST_INTERVAL    (1500)                                           //ÿ����ms��Yeelink����һ��
#define  HOST_NAME           "www.yeelink.net"
#define  API_KEY             "57b01b6203cd67fb505d2dbcf71283ea\r\n"           //ע���©������\r\n
#define  DEVICE_ID           "351010"
#define  SENSOR_LED1_ID      "394251"
#define  SENSOR_LED2_ID      "394255"
#define  SENSOR_LED3_ID      "394257"
#define  SENSOR_LED4_ID      "394258"
//-----------------------------------------------------------------------------------------------------------------


//�궨��===========================================================================================================
#define  YEELINK_REQ_SEQ_1        "GET /v1.0/device/"                                   //����������豸��
#define  YEELINK_REQ_SEQ_2        "/sensor/"                                           //��������ϴ�������
#define  YEELINK_REQ_SEQ_3        "/datapoints HTTP/1.1\r\n"
#define  YEELINK_REQ_SEQ_4        "Host:api.yeelink.net\r\n"
#define  YEELINK_REQ_SEQ_5        "U-ApiKey:"                                          //���������API��
#define  YEELINK_REQ_SEQ_6        "Accept: */*\r\n"
#define  YEELINK_REQ_SEQ_7        "Content-Type: application/x-www-form-urlencoded\r\n"
#define  YEELINK_REQ_SEQ_8        "Connection: close\r\n"
#define  YEELINK_REQ_SEQ_9        "\r\n"
#define  YEELINK_REQ_SEQ_10       "\r\n"
#define  YEELINK_REQ_SEQ_11       "------207\r\n"
//-----------------------------------------------------------------------------------------------------------------


//extern ����============================================================
extern  ip_addr_t  Yeelink_IP;
extern  u8         Yeelink_DNS_OK;
extern  u8         CurSensor;
//-----------------------------------------------------------------------

//�������� ==============================================================
void Yeelink_DNS_Parse(void);
void Yeelink_Variable_Init(void);
void Yeelink_Polling(u8 n);
void Yeelink_Do_After_Recv(void *P);
//-----------------------------------------------------------------------


#endif
