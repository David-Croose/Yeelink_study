#ifndef __LED_H
#define __LED_H
#include "sys.h"

//LED�˿ڶ���
#define LED1 PDout(12)
#define LED2 PDout(13)
#define LED3 PDout(14)	
#define LED4 PDout(15)


void led_init(void);//��ʼ��		 				    
#endif
