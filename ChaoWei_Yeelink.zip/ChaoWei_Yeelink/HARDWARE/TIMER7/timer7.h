#ifndef _TIMER7_H_
#define _TIMER7_H_

#include "sys.h"


extern  volatile uint32_t  ulHighFrequencyTimerTicks;

void TIM7_Int_Init(u16 arr,u16 psc);


#endif
