#include "delay.h"
#include "sys.h"
#include "timer3.h"

void delay_init(u16 n)
{
    (void)n;
    
    Timer3_Counter=0;
}

void delay_ms(u16 nms)
{
    TIM3_Int_Init(nms*10-1, 8400-1);  //1mS
    Timer3_Counter=0;
    while(Timer3_Counter<1);
    TIM_Cmd(TIM3,DISABLE);
}    

void delay_us(u32 nus)
{
    u8      i;
    
    while(nus--)
    for(i=0;i<6;i++)
        __NOP();
}




